package com.example.item;

public class ItemLatest {

	private String NewsId;
	private String NewsTitle;
	private String NewsImage;
	private String NewsImageSmall;
	private String NewsDate;
	private String NewsView;
	private String NewsDesc;
	private String NewsType;
	private String NewsVideoId;
	private String NewsVideourl;

	public String getNewsVideourl() {
		return NewsVideourl;
	}

	public void setNewsVideourl(String newsVideourl) {
		NewsVideourl = newsVideourl;
	}

	public ItemLatest() {
		// TODO Auto-generated constructor stub
	}

	public String getNewsId() { return NewsId; }
	public void setNewsId(String NewsId) { this.NewsId = NewsId; }

	public String getNewsImageSmall() { return NewsImageSmall; }
	public void setNewsImageSmall(String NewsImageSmall) { this.NewsImageSmall = NewsImageSmall; }

	public String getNewsTitle() { return NewsTitle; }
	public void setNewsTitle(String NewsTitle) { this.NewsTitle = NewsTitle; }

	public String getNewsImage() { return NewsImage; }
	public void setNewsImage(String NewsImage) { this.NewsImage = NewsImage; }

	public String getNewsDate() { return NewsDate; }
	public void setNewsDate(String NewsDate) { this.NewsDate = NewsDate; }

	public String getNewsView() { return NewsView; }
	public void setNewsView(String NewsView) { this.NewsView = NewsView; }

	public String getNewsDesc() { return NewsDesc; }
	public void setNewsDesc(String NewsDesc) { this.NewsDesc = NewsDesc; }

	public String getNewsType() { return NewsType; }
	public void setNewsType(String NewsType) { this.NewsType = NewsType; }

	public String getNewsVideoId() { return NewsVideoId; }
	public void setNewsVideoId(String NewsVideoId) { this.NewsVideoId = NewsVideoId; }

}
