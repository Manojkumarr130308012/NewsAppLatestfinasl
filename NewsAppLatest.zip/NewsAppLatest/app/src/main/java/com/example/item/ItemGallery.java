package com.example.item;


public class ItemGallery {

    private String GaImage;
    private String GaType;
    private String GaPlayId;

    public String getGaImage() {
        return GaImage;
    }

    public void setGaImage(String gaImage) {
        GaImage = gaImage;
    }

    public String getGaType() {
        return GaType;
    }

    public void setGaType(String gaType) {
        GaType = gaType;
    }

    public String getGaPlayId() {
        return GaPlayId;
    }

    public void setGaPlayId(String gaPlayId) {
        GaPlayId = gaPlayId;
    }


}
